----------------------------------------------------------------------

Instruction to setup the environment:

1.Create a database in your mySql workbench
2.Change the configurations in dabase.js file to match your database
3.Create the tabale in your database as given in the sql_table.txt file.

Demostration:
A recorded demostration of this app is provided. Check recording.wmv file.

---------------------Thank You!-----------------------------------------